## Website Performance Optimization portfolio project

This is a simple portifolio page. The basic code was forked from UDACITY in [this link](https://github.com/udacity/frontend-nanodegree-mobile-portfolio).

## Instalation
You must a have a browser to open the pages. We recommend Chrome Browser.
Download all the files in this repo and open
index.html file to begin the game.
```
$ git clone https://github.com/udacity/frontend-nanodegree-mobile-portfolio
```
## Opening
Go to the folder where you cloned the application and
open the file 'index.html' using your browser. After
you will be able to navigate to several pages in the
portifolio.
